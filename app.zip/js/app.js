$(document).ready(function(){
  $('.slider').slick({
    dots: false,
    infinite: true,
    speed: 300,
    slidesToShow: 2,
    centerMode: true,
    variableWidth: true
  });
});